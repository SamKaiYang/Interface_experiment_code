/* Includes ------------------------------------------------------------------------------------------------*/
#include "ht32.h"
#include "ht32_board.h"
#include "ht32_board_config.h"
void delay();

void CKCU_configuration(void)
{
  CKCU_PeripClockConfig_TypeDef CKCUClock = {{0}};
	CKCUClock.Bit.PC = 1;
  CKCUClock.Bit.AFIO       = 1;
  CKCU_PeripClockConfig(CKCUClock, ENABLE);
}
void GPIO_configuration(void)
{                                                   
  /* 設定映射到腳位上之功能                                                                     */
  AFIO_GPxConfig(GPIO_PC, AFIO_PIN_14, AFIO_FUN_GPIO);

  /* 設定腳位I/O方向                                                                */
  GPIO_DirectionConfig(HT_GPIOC, GPIO_PIN_14, GPIO_DIR_OUT);
}
int main(void)
{
  FlagStatus TmpStatus1 = SET;
	FlagStatus TmpStatus2 = RESET;
	/*CKCU SET                */
  CKCU_configuration();
	GPIO_configuration();
  /* Infinite loop to read data from input pin and then output to LED                                       */
  while (1)
  {
    /* LED */
    GPIO_WriteOutBits(HT_GPIOC, GPIO_PIN_14, TmpStatus1);
		delay();
		GPIO_WriteOutBits(HT_GPIOC, GPIO_PIN_14, TmpStatus2);
		delay();
  }
}


void delay(){
  int i;
  for(i=0; i<0xffffff; ++i);
}
#if (HT32_LIB_DEBUG == 1)
/*********************************************************************************************************//**
  * @brief  Report both the error name of the source file and the source line number.
  * @param  filename: pointer to the source file name.
  * @param  uline: error line source number.
  * @retval None
  ***********************************************************************************************************/
void assert_error(u8* filename, u32 uline)
{
  /*
     This function is called by IP library that the invalid parameters has been passed to the library API.
     Debug message can be added here.
     Example: printf("Parameter Error: file %s on line %d\r\n", filename, uline);
  */

  while (1)
  {
  }
}
#endif


/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */
