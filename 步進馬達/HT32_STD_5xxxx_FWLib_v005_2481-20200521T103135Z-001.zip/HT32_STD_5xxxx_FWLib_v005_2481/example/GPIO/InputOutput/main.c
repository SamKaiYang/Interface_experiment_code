/* Includes ------------------------------------------------------------------------------------------------*/
#include "ht32.h"
#include "ht32_board.h"
#include "ht32_board_config.h"

#define angle 90 ;

void CKCU_configuration(void)
{
  CKCU_PeripClockConfig_TypeDef CKCUClock = {{0}};
	CKCUClock.Bit.PA = 1;
	CKCUClock.Bit.PB = 1;
  CKCUClock.Bit.AFIO       = 1;
  CKCU_PeripClockConfig(CKCUClock, ENABLE);
}
void GPIO_configuration(void)
{                                                   
  /* 設定映射到腳位上之功能                                                                     */
  AFIO_GPxConfig(GPIO_PA, AFIO_PIN_0 | AFIO_PIN_1, AFIO_FUN_GPIO);
	AFIO_GPxConfig(GPIO_PB, AFIO_PIN_0 | AFIO_PIN_1, AFIO_FUN_GPIO);
  /* 設定腳位I/O方向                                                                */
  GPIO_DirectionConfig(HT_GPIOA, GPIO_PIN_0 | GPIO_PIN_1, GPIO_DIR_OUT);
	GPIO_DirectionConfig(HT_GPIOB, GPIO_PIN_0 | GPIO_PIN_1, GPIO_DIR_OUT);
}

void delay(void){
  int i;
  for(i=0; i<10000; ++i);//20000000  10000 * X
}
int i = 1;
int main(void)
{
	/*CKCU SET                */
  CKCU_configuration();
	GPIO_configuration();
  /* Infinite loop to read data from input pin and then output to LED                                       */
	
  /*for(i=1;i<=512;i++)
	{
      GPIO_WriteOutBits(HT_GPIOA,GPIO_PIN_0,0);
      GPIO_WriteOutBits(HT_GPIOA,GPIO_PIN_1,0);
      GPIO_WriteOutBits(HT_GPIOB,GPIO_PIN_0,0);
      GPIO_WriteOutBits(HT_GPIOB,GPIO_PIN_1,1);
      delay();
      GPIO_WriteOutBits(HT_GPIOA,GPIO_PIN_0,0);
      GPIO_WriteOutBits(HT_GPIOA,GPIO_PIN_1,0);
      GPIO_WriteOutBits(HT_GPIOB,GPIO_PIN_0,1);
      GPIO_WriteOutBits(HT_GPIOB,GPIO_PIN_1,1);
      delay();
      GPIO_WriteOutBits(HT_GPIOA,GPIO_PIN_0,0);
      GPIO_WriteOutBits(HT_GPIOA,GPIO_PIN_1,0);
      GPIO_WriteOutBits(HT_GPIOB,GPIO_PIN_0,1);
      GPIO_WriteOutBits(HT_GPIOB,GPIO_PIN_1,0);
      delay();
      GPIO_WriteOutBits(HT_GPIOA,GPIO_PIN_0,0);
      GPIO_WriteOutBits(HT_GPIOA,GPIO_PIN_1,1);
      GPIO_WriteOutBits(HT_GPIOB,GPIO_PIN_0,1);
      GPIO_WriteOutBits(HT_GPIOB,GPIO_PIN_1,0);
      delay();
			GPIO_WriteOutBits(HT_GPIOA,GPIO_PIN_0,0);
      GPIO_WriteOutBits(HT_GPIOA,GPIO_PIN_1,1);
      GPIO_WriteOutBits(HT_GPIOB,GPIO_PIN_0,0);
      GPIO_WriteOutBits(HT_GPIOB,GPIO_PIN_1,0);
      delay();
      GPIO_WriteOutBits(HT_GPIOA,GPIO_PIN_0,1);
      GPIO_WriteOutBits(HT_GPIOA,GPIO_PIN_1,1);
      GPIO_WriteOutBits(HT_GPIOB,GPIO_PIN_0,0);
      GPIO_WriteOutBits(HT_GPIOB,GPIO_PIN_1,0);
      delay();
      GPIO_WriteOutBits(HT_GPIOA,GPIO_PIN_0,1);
      GPIO_WriteOutBits(HT_GPIOA,GPIO_PIN_1,0);
      GPIO_WriteOutBits(HT_GPIOB,GPIO_PIN_0,0);
      GPIO_WriteOutBits(HT_GPIOB,GPIO_PIN_1,0);
      delay();
      GPIO_WriteOutBits(HT_GPIOA,GPIO_PIN_0,1);
      GPIO_WriteOutBits(HT_GPIOA,GPIO_PIN_1,0);
      GPIO_WriteOutBits(HT_GPIOB,GPIO_PIN_0,0);
      GPIO_WriteOutBits(HT_GPIOB,GPIO_PIN_1,1);
      delay();
	}*/

  for(i=1;i<=512;i++)
	{
      GPIO_WriteOutBits(HT_GPIOA,GPIO_PIN_0,1);
      GPIO_WriteOutBits(HT_GPIOA,GPIO_PIN_1,0);
      GPIO_WriteOutBits(HT_GPIOB,GPIO_PIN_0,0);
      GPIO_WriteOutBits(HT_GPIOB,GPIO_PIN_1,1);
      delay();
      GPIO_WriteOutBits(HT_GPIOA,GPIO_PIN_0,1);
      GPIO_WriteOutBits(HT_GPIOA,GPIO_PIN_1,0);
      GPIO_WriteOutBits(HT_GPIOB,GPIO_PIN_0,0);
      GPIO_WriteOutBits(HT_GPIOB,GPIO_PIN_1,0);
      delay();
      GPIO_WriteOutBits(HT_GPIOA,GPIO_PIN_0,1);
      GPIO_WriteOutBits(HT_GPIOA,GPIO_PIN_1,1);
      GPIO_WriteOutBits(HT_GPIOB,GPIO_PIN_0,0);
      GPIO_WriteOutBits(HT_GPIOB,GPIO_PIN_1,0);
      delay();
      GPIO_WriteOutBits(HT_GPIOA,GPIO_PIN_0,0);
      GPIO_WriteOutBits(HT_GPIOA,GPIO_PIN_1,1);
      GPIO_WriteOutBits(HT_GPIOB,GPIO_PIN_0,0);
      GPIO_WriteOutBits(HT_GPIOB,GPIO_PIN_1,0);
      delay();
			GPIO_WriteOutBits(HT_GPIOA,GPIO_PIN_0,0);
      GPIO_WriteOutBits(HT_GPIOA,GPIO_PIN_1,1);
      GPIO_WriteOutBits(HT_GPIOB,GPIO_PIN_0,1);
      GPIO_WriteOutBits(HT_GPIOB,GPIO_PIN_1,0);
      delay();
      GPIO_WriteOutBits(HT_GPIOA,GPIO_PIN_0,0);
      GPIO_WriteOutBits(HT_GPIOA,GPIO_PIN_1,0);
      GPIO_WriteOutBits(HT_GPIOB,GPIO_PIN_0,1);
      GPIO_WriteOutBits(HT_GPIOB,GPIO_PIN_1,0);
      delay();
      GPIO_WriteOutBits(HT_GPIOA,GPIO_PIN_0,0);
      GPIO_WriteOutBits(HT_GPIOA,GPIO_PIN_1,0);
      GPIO_WriteOutBits(HT_GPIOB,GPIO_PIN_0,1);
      GPIO_WriteOutBits(HT_GPIOB,GPIO_PIN_1,1);
      delay();
      GPIO_WriteOutBits(HT_GPIOA,GPIO_PIN_0,0);
      GPIO_WriteOutBits(HT_GPIOA,GPIO_PIN_1,0);
      GPIO_WriteOutBits(HT_GPIOB,GPIO_PIN_0,0);
      GPIO_WriteOutBits(HT_GPIOB,GPIO_PIN_1,1);
      delay();
	}
}



#if (HT32_LIB_DEBUG == 1)
/*********************************************************************************************************//**
  * @brief  Report both the error name of the source file and the source line number.
  * @param  filename: pointer to the source file name.
  * @param  uline: error line source number.
  * @retval None
  ***********************************************************************************************************/
void assert_error(u8* filename, u32 uline)
{
  /*
     This function is called by IP library that the invalid parameters has been passed to the library API.
     Debug message can be added here.
     Example: printf("Parameter Error: file %s on line %d\r\n", filename, uline);
  */

  while (1)
  {
  }
}
#endif


/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */
